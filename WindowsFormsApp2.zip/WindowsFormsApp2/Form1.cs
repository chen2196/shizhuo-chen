﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;
using System.Configuration;
using System.Data.SqlClient;

namespace WindowsFormsApp2
{
    //This application uses an extension library called Gmap.Net for map and other functions related to it.
    //All the national parks in the app are stored in a local database.
    //No API is called
    public partial class Form1 : Form
    {
        string connectionString = ConfigurationManager.ConnectionStrings["WindowsFormsApp2.Properties.Settings.Database1ConnectionString"].ConnectionString;
        string query = "select * from parks where Name = @Name";

        GMarkerGoogle marker;
        GMapOverlay mapOverlay;
        DataTable dt;
        GMapOverlay Poligono = new GMapOverlay("Polygon");
        GMapOverlay Routa = new GMapOverlay("Route");
        GDirections Routsdir;
        List<PointLatLng> points = new List<PointLatLng>();
        List<Tuple<double, double>> datry = new List<Tuple<double, double>>();

        int RowSelected = 0;
        double inilong = -86.9080556;
        double inilat = 40.4258333;
        //Initial position of the map and the pointer when you open it
        public Form1()
        {
            InitializeComponent();
            AutoCompleteText();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //The code below is to initialize the map, the pointer on the map, and the data grid view
            dt = new DataTable();
            dt.Columns.Add(new DataColumn("Name", typeof(string)));
            dt.Columns.Add(new DataColumn("Address", typeof(string)));
            
            dataGridView1.DataSource = dt;

            gMapControl1.DragButton = MouseButtons.Left;
            gMapControl1.CanDragMap = true;
            gMapControl1.MapProvider = GMapProviders.GoogleMap;
            gMapControl1.Position = new PointLatLng(inilat, inilong);
            gMapControl1.MinZoom = 0;
            gMapControl1.MaxZoom = 24;
            gMapControl1.Zoom = 13;
            gMapControl1.AutoScroll = true;

            mapOverlay = new GMapOverlay("marker");
            marker = new GMarkerGoogle(new PointLatLng(inilat, inilong), GMarkerGoogleType.green);
            mapOverlay.Markers.Add(marker);
            marker.ToolTipMode = MarkerTooltipMode.Always;
            marker.ToolTipText = $"Latitude:{inilat}, longitude: {inilong}";
            gMapControl1.Overlays.Add(mapOverlay);
        }

        private void Registry(object sender, DataGridViewCellMouseEventArgs e)
        {
            //When you click on any of the rows in data gridview, the text description and the map both change
            RowSelected = e.RowIndex;
            txtdescription.Text = dataGridView1.Rows[RowSelected].Cells[0].Value.ToString();
            marker.Position = new PointLatLng(datry[RowSelected].Item1,datry[RowSelected].Item2);
            marker.ToolTipText = $" Latitude:{marker.Position.Lat}, Longitude:{marker.Position.Lng}";
            gMapControl1.Position = marker.Position;
        }

        private void gMapControl1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            //Double click on anywhere on the map and the pointer and the map position will move to your click and the description will be the address
            double lat = gMapControl1.FromLocalToLatLng(e.X, e.Y).Lat;
            double lng = gMapControl1.FromLocalToLatLng(e.X, e.Y).Lng;
            GeoCoderStatusCode status;
            Placemark pos = (Placemark)GMapProviders.GoogleMap.GetPlacemark(new PointLatLng(lat, lng), out status);

            txtdescription.Text = pos.Address;

            marker.Position = new PointLatLng(lat, lng);
            marker.ToolTipText = $"latitude {lat} longitude {lng}";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //The Add button to add a place to the data grid view
            GeoCoderStatusCode status;
            Placemark pos = (Placemark)GMapProviders.GoogleMap.GetPlacemark(new PointLatLng(marker.Position.Lat,marker.Position.Lng), out status);
            dt.Rows.Add(txtdescription.Text,pos.Address);
            datry.Add(Tuple.Create(marker.Position.Lat, marker.Position.Lng));
            points.Add(new PointLatLng(datry[datry.Count-1].Item1
                ,datry[datry.Count-1].Item2));

        }

        private void button2_Click(object sender, EventArgs e)
        {
            //The Clear button to remove one row out of the grid view
            dataGridView1.Rows.RemoveAt(RowSelected);
            points.RemoveAt(RowSelected);
            datry.RemoveAt(RowSelected);
        }

        private void txtpolygon_Click(object sender, EventArgs e)
        {
            //The Polygon button to draw a polygon with all the points in the gridview

            if (gMapControl1.Overlays.Contains(Poligono))
            {
                Poligono.Polygons.Clear();
                gMapControl1.Overlays.Remove(Poligono);
            }
            else
            {
                GMapPolygon polygonpoints = new GMapPolygon(points, "Polygon");
                Poligono.Polygons.Add(polygonpoints);
                gMapControl1.Overlays.Add(Poligono);
                gMapControl1.Zoom = gMapControl1.Zoom + 1;
                gMapControl1.Zoom = gMapControl1.Zoom - 1;
            }
        }

        private void button3_Click(object sender, EventArgs e) 
        {
            //The Direction button to show the road you need to go through all the places in the grid view. It is in car mode and does not avoid highways or tolls
            //If you click, the route will show, if you click again, it will disappear 
            if (gMapControl1.Overlays.Contains(Routa))
            {
                Routa.Routes.Clear();
                gMapControl1.Overlays.Remove(Routa);
                txtDistance.Text = string.Empty;
            }
            else
            {
                var routefromap = GMapProviders.GoogleMap.GetDirections(out Routsdir, points[0], points, points[points.Count - 1], false, false, false, false, true);
                GMapRoute tablemaproute = new GMapRoute(Routsdir.Route, "Route");
                Routa.Routes.Add(tablemaproute);
                gMapControl1.Overlays.Add(Routa);
                gMapControl1.Zoom = gMapControl1.Zoom + 1;
                gMapControl1.Zoom = gMapControl1.Zoom - 1;
                txtDistance.Text = tablemaproute.Distance.ToString();
            }
        }

        private void btnSat_Click(object sender, EventArgs e)
        {
            //Satellite version of the map
            gMapControl1.MapProvider = GMapProviders.GoogleSatelliteMap;
        }

        private void btnOriginal_Click(object sender, EventArgs e)
        {
            //Original map
            gMapControl1.MapProvider = GMapProviders.GoogleMap;
        }

        private void btnRelief_Click(object sender, EventArgs e)
        {
            //Relief version of the map
            gMapControl1.MapProvider = GMapProviders.GoogleTerrainMap;
        }

        

        private void timer1_Tick(object sender, EventArgs e)
        {
            //This timer is to help determine whether the zoom bar should move automatically according to the zoom level of the map
            trackZoom.Value = (int)gMapControl1.Zoom;
        }

        private void trackZoom_ValueChanged(object sender, EventArgs e)
        {
            gMapControl1.Zoom = trackZoom.Value;
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //This search button uses geocoding, so if you type the full adderss of a place, the map will take you there
            GeoCoderStatusCode status;
            string address = cboSearch.Text;
            PointLatLng? point = GMapProviders.GoogleMap.GetPoint(address, out status);
            if (status == GeoCoderStatusCode.G_GEO_SUCCESS & point != null)
            {
                double nlat = point.Value.Lat;
                double nlng = point.Value.Lng;

                marker.Position = new PointLatLng(nlat, nlng);
                gMapControl1.Position = new PointLatLng(nlat, nlng);
            }
            else
            {
                string message = "Your address may have an error";
                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show(message, string.Empty,buttons);
                    
            }
        }

        private void AutoCompleteText()
        {
            //This method connects the database and use the park names to populate the combobox drop down list
            cboSearch.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            cboSearch.AutoCompleteSource = AutoCompleteSource.CustomSource;
            AutoCompleteStringCollection coll = new AutoCompleteStringCollection();

            
            using (SqlConnection con = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand("select * from parks", con))
            {
                try
                {
                    con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        string name = Convert.ToString(reader["Name"]);
                        coll.Add(name);
                        cboSearch.Items.Add(name);
                    }
                }
                catch(Exception e)
                {
                    MessageBox.Show(e.Message);
                }
                cboSearch.AutoCompleteCustomSource = coll;
            }
        }

        private void cboSearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            //When you select a park from the drop down list, the map will automatically take you there and the text description will be the park's wikipedia description.
            using (SqlConnection connection = new SqlConnection(connectionString))
            using (SqlCommand command = new SqlCommand(query, connection))
            {
                connection.Open();
                command.Parameters.AddWithValue("@Name", cboSearch.Text);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    double lat = Convert.ToDouble(reader["Latitude"]);
                    double lon = Convert.ToDouble(reader["Longitude"]);
                    string des = Convert.ToString(reader["Description"]);

                    marker.Position = new PointLatLng(lat, lon);
                    gMapControl1.Position = new PointLatLng(lat, lon);
                    txtdescription.Text = des;
                }
            }
        }
    }
}
