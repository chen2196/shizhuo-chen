﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GMap.NET;
using GMap.NET.MapProviders;
using GMap.NET.WindowsForms;
using GMap.NET.WindowsForms.Markers;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        GMarkerGoogle marker;
        GMapOverlay mapOverlay;
        DataTable dt;
        GMapOverlay Poligono = new GMapOverlay("Polygon");
        GDirections Routsdir;
        List<PointLatLng> points = new List<PointLatLng>();

        int RowSelected = 0;
        double inilong = -86.9080556;
        double inilat = 40.4258333;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            dt = new DataTable();
            dt.Columns.Add(new DataColumn("Description", typeof(string)));
            dt.Columns.Add(new DataColumn("Lat", typeof(double)));
            dt.Columns.Add(new DataColumn("Long", typeof(double)));
            dataGridView1.DataSource = dt;

            gMapControl1.DragButton = MouseButtons.Left;
            gMapControl1.CanDragMap = true;
            gMapControl1.MapProvider = GMapProviders.GoogleMap;
            gMapControl1.Position = new PointLatLng(inilat, inilong);
            gMapControl1.MinZoom = 0;
            gMapControl1.MaxZoom = 24;
            gMapControl1.Zoom = 13;
            gMapControl1.AutoScroll = true;

            mapOverlay = new GMapOverlay("marker");
            marker = new GMarkerGoogle(new PointLatLng(inilat, inilong), GMarkerGoogleType.green);
            mapOverlay.Markers.Add(marker);
            marker.ToolTipMode = MarkerTooltipMode.Always;
            marker.ToolTipText = $"Latitude:{inilat}, longitude: {inilong}";
            gMapControl1.Overlays.Add(mapOverlay);
        }

        private void Registry(object sender, DataGridViewCellMouseEventArgs e)
        {
            RowSelected = e.RowIndex;
            txtdescription.Text = dataGridView1.Rows[RowSelected].Cells[0].Value.ToString();
            txtLat.Text = dataGridView1.Rows[RowSelected].Cells[1].Value.ToString();
            txtLong.Text = dataGridView1.Rows[RowSelected].Cells[2].Value.ToString();
            marker.Position = new PointLatLng(Convert.ToDouble(txtLat.Text), Convert.ToDouble(txtLong.Text));
            marker.ToolTipText = $" Latitude:{marker.Position.Lat}, Longitude:{marker.Position.Lng}";
            gMapControl1.Position = marker.Position;
        }

        private void gMapControl1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            double lat = gMapControl1.FromLocalToLatLng(e.X, e.Y).Lat;
            double lng = gMapControl1.FromLocalToLatLng(e.X, e.Y).Lng;

 
            txtLat.Text = lat.ToString();
            txtLong.Text = lng.ToString();

            marker.Position = new PointLatLng(lat, lng);
            marker.ToolTipText = $"latitude {lat} longitude {lng}";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            dt.Rows.Add(txtdescription.Text, marker.Position.Lat, marker.Position.Lng);
            points.Add(new PointLatLng(Convert.ToDouble(dataGridView1.Rows[dataGridView1.Rows.Count-1].Cells[1].Value)
                , Convert.ToDouble(dataGridView1.Rows[dataGridView1.Rows.Count - 1].Cells[2].Value) ));

        }

        private void button2_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.RemoveAt(RowSelected);
            points.RemoveAt(RowSelected);
        }

        private void txtpolygon_Click(object sender, EventArgs e)
        {

            if (gMapControl1.Overlays.Contains(Poligono))
            {
                Poligono.Polygons.Clear();
                gMapControl1.Overlays.Remove(Poligono);
            }
            else
            {
                GMapPolygon polygonpoints = new GMapPolygon(points, "Polygon");
                Poligono.Polygons.Add(polygonpoints);
                gMapControl1.Overlays.Add(Poligono);
                gMapControl1.Zoom = gMapControl1.Zoom + 1;
                gMapControl1.Zoom = gMapControl1.Zoom - 1;
            }
        }

        private void button3_Click(object sender, EventArgs e) 
        {
            var routefromap = GMapProviders.GoogleMap.GetDirections(out Routsdir, points[0], points, points[points.Count - 1], false, false, false, false,true);
            GMapRoute tablemaproute = new GMapRoute(Routsdir.Route, "Route");
            GMapOverlay mapOverlay = new GMapOverlay("Route Layer");
            mapOverlay.Routes.Add(tablemaproute);
            gMapControl1.Overlays.Add(mapOverlay);
            gMapControl1.Zoom = gMapControl1.Zoom + 1;
            gMapControl1.Zoom = gMapControl1.Zoom - 1;
            txtDistance.Text = tablemaproute.Distance.ToString();
        }
    }
}
